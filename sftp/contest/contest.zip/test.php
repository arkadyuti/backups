<?php
$str = "abc57";
$result = substr($str, 0,3);
echo $result;


$case = "abc41";
$result = substr($case, 3,5);
echo '<br>'.$result;
?>