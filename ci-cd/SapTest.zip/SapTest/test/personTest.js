require("../person");
require("chai").should();
describe("Person", function () {
	it("greet people", function () {
		var p1 = new Person("Arka");
		var p2 = new Person("Sarkar");

		p1.greet(p2).should.equal("Hello, Sarkar!");
	});


	it("greets strings", function () {
		var p1 = new Person("Arka");

		p1.greet("Sarkar").should.equal("Hello, Sarkar!");
	});
})